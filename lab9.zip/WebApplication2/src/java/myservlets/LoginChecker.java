package myservlets;

public class LoginChecker
{

    public static boolean validate(String name,String pass)
    {
        boolean status=false;
        try
        {
           status = name.equals(pass);
	}
        catch(Exception e)
        {
            System.out.println(e);
        }
        return status;
    }
}
